#include <stdio.h>

// Function to calculate factorial of a number
unsigned long long factorial(int num) {
    if (num <= 1)
        return 1;
    else
        return num * factorial(num - 1);
}

// Function to calculate sum of factorial series
unsigned long long sumFactorialSeries(int n) {
    unsigned long long sum = 0;

    for (int i = 1; i <= n; i++) {
        sum += factorial(i);
    }

    return sum;
}

int main() {
    int n;
    printf("Enter the value of n: ");
    scanf("%d", &n);

    unsigned long long result = sumFactorialSeries(n);

    printf("The sum of the series 1! + 2! + 3! + ... + %d! = %llu\n", n, result);

    return 0;
}
