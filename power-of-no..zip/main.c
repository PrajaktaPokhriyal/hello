#include <stdio.h>

double power(double base, int exponent) {
    double result = 1.0;

    for (int i = 0; i < exponent; i++) {
        result *= base;
    }

    return result;
}

int main() {
    double base;
    int exponent;
printf("Prajakta Pokhriyal \n");
    printf("Enter the base: ");
    scanf("%lf", &base);

    printf("Enter the exponent: ");
    scanf("%d", &exponent);

    if (exponent < 0) {
        printf("Exponent should be a non-negative integer.\n");
        return 1;
    }

    double result = power(base, exponent);

    printf("%.2lf raised to the power %d is: %.2lf\n", base, exponent, result);

    return 0;
}
