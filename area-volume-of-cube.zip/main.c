 #include <stdio.h>
 int main() {
   	 double sideLength, area, volume;
    	printf("Enter the side length of the cube: ");
    	scanf("%lf", &sideLength);
   	 area = 6 * sideLength * sideLength;
    	volume = sideLength * sideLength * sideLength;
printf("The surface area of the cube is: %.2lf square units\n", area);
    	printf("The volume of the cube is: %.2lf cubic units\n", volume);
    	return 0;
}
