#include <stdio.h>
#include <string.h>

int octalToDecimal(char octal[]) {
    int length = strlen(octal);
    int decimal = 0;

    for (int i = 0; i < length; i++) {
        if (octal[i] >= '0' && octal[i] <= '7') {
            decimal = decimal * 8 + (octal[i] - '0');
        } else {
            printf("Invalid octal input.\n");
            return -1;  // Return -1 for invalid input
        }
    }

    return decimal;
}

void decimalToHexadecimal(int decimal) {
    char hexadecimal[100];
    int i = 0;

    while (decimal != 0) {
        int remainder = decimal % 16;
        if (remainder < 10)
            hexadecimal[i++] = remainder + '0';
        else
            hexadecimal[i++] = remainder + 'A' - 10;
        decimal /= 16;
    }

    printf("Hexadecimal equivalent: ");
    for (int j = i - 1; j >= 0; j--)
        printf("%c", hexadecimal[j]);
    printf("\n");
}

int main() {
    char octal[100];
printf("Prajakta Pokhriyal \n");
    printf("Enter an octal number: ");
    scanf("%s", octal);

    int decimal = octalToDecimal(octal);

    if (decimal != -1)
        decimalToHexadecimal(decimal);

    return 0;
}
