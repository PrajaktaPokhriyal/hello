#include <stdio.h>
#include <math.h>

// Function to calculate the sum of the series
double sumSeries(int n, int r) {
    double sum = 0.0;

    for (int i = 1; i <= n; i++) {
        sum += pow(i, r);
    }

    return sum;
}

int main() {
    int n, r;
    printf("Enter the value of n: ");
    scanf("%d", &n);
    printf("Enter the value of r: ");
    scanf("%d", &r);

    double result = sumSeries(n, r);
    printf("The sum of the series is: %.2f\n", result);

    return 0;
}
series