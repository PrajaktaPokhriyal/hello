	#include <stdio.h>
   	int main() {
int a,s;
printf("Enter the side of the square:");
scanf("%d",&s);
a = s*s;
printf("/n The area of the square is : %d",a);
 return 0;
} 
