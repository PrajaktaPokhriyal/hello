#include <stdio.h>
#include <math.h>

int isArmstrong(int num) {
    int originalNum = num;
    int sum = 0, remainder;

    int digits = 0;
    while (originalNum != 0) {
        originalNum /= 10;
        digits++;
    }

    originalNum = num;
    while (originalNum != 0) {
        remainder = originalNum % 10;
        sum += pow(remainder, digits);
        originalNum /= 10;
    }

    return (sum == num);
}

void printArmstrongNumbers(int n) {
    printf("Armstrong numbers between 1 and %d are:\n", n);

    for (int i = 1; i <= n; i++) {
        if (isArmstrong(i))
            printf("%d ", i);
    }

    printf("\n");
}

int main() {
    int n;
printf("Prajakta Pokhriyal \n");
    printf("Enter a number: ");
    scanf("%d", &n);

    printArmstrongNumbers(n);

    return 0;
}
