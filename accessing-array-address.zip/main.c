// Online C compiler to run C program online
#include <stdio.h>

int main() {
    
    int num[]={24,34,12,44,56,17};
int i=0;
while(i<=5){
    printf("\n address is %u",&num[i]);
    printf("element =%d",num[i]);
    i++;
}
}