#include <stdio.h>
#include <string.h>

int binaryToDecimal(char binary[]) {
    int length = strlen(binary);
    int decimal = 0;

    for (int i = 0; i < length; i++) {
        if (binary[i] == '1')
            decimal = (decimal << 1) | 1;  // Multiply by 2 and add 1
        else if (binary[i] == '0')
            decimal = decimal << 1;  // Multiply by 2
        else {
            printf("Invalid binary input.\n");
            return -1;  // Return -1 for invalid input
        }
    }

    return decimal;
}

int main() {
    char binary[100];
printf("Prajakta Pokhriyal \n");
    printf("Enter a binary number: ");
    scanf("%s", binary);

    int decimal = binaryToDecimal(binary);

    if (decimal != -1)
        printf("Decimal equivalent: %d\n", decimal);

    return 0;
}
