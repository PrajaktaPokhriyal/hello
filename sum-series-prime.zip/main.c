#include <stdio.h>

int isPrime(int n, int i) {
    if (i == 1) {
        return 1; // Base case, when i reaches 1
    } else {
        if (n % i == 0) {
            return 0; // Not a prime number
        } else {
            return isPrime(n, i - 1); // Recursively check for divisibility
        }
    }
}

int nthPrime(int n) {
    int count = 0, num = 2;
    while (count < n) {
        if (isPrime(num, num / 2) == 1) {
            count++;
        }
        num++;
    }
    return num - 1;
}

int sumPrimeSeries(int n) {
    if (n == 1) {
        return 1;
    } else {
        int currentPrime = nthPrime(n);
        return currentPrime + sumPrimeSeries(n - 1);
    }
}

int main() {
    int limit;
    printf("Enter the value of n: ");
    scanf("%d", &limit);

    int sum = sumPrimeSeries(limit);
    printf("The sum of the series up to the %dth prime number is: %d\n", limit, sum);

    return 0;
}
