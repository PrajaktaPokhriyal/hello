              
          #include <stdio.h>
int main() {
int a,b,c;
printf("Enter 1st number:");
scanf("%d",&a);
printf("Enter 2nd number:");
scanf("%d",&b);
printf("Enter 3rd number:");
scanf("%d",&c);
a=a+b+c;
b=a-(b+c);
c=a-(b+c);
a=a-(b+c);
printf("int%d",a);
printf("int%d",b);

printf("int%d",c);
printf("%d",a);
printf("/n In a Swap Number are a=%d , b=%d , c=%d",a,b,c);
return 0;
}
