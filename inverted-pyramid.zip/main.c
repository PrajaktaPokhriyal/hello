#include <stdio.h>

void printInvertedPyramid(int n) {
    for (int i = n; i >= 1; i--) {
        for (int j = 1; j <= n - i; j++)
            printf(" ");
        for (int k = 1; k <= 2 * i - 1; k++)
            printf("*");
        printf("\n");
    }
}

int main() {
    int rows;
printf("Prajakta Pokhriyal \n");
    printf("Enter the number of rows for the inverted pyramid: ");
    scanf("%d", &rows);

    printInvertedPyramid(rows);

    return 0;
}
