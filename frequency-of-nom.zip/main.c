#include <stdio.h>

int main() {
    int number, digit;
    int frequency[10] = {0};  // Array to store frequency of each digit
printf("Prajakta Pokhriyal \n");
    printf("Enter an integer: ");
    scanf("%d", &number);

    while (number != 0) {
        digit = number % 10;  // Extract the last digit
        frequency[digit]++;    // Increment the frequency for that digit
        number /= 10;          // Move to the next digit
    }

    printf("Frequency of each digit:\n");
    for (int i = 0; i < 10; i++) {
        if (frequency[i] > 0)
            printf("Digit %d: %d times\n", i, frequency[i]);
    }

    return 0;
}
