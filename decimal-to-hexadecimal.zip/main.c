#include <stdio.h>

void decimalToHexadecimal(int decimal) {
    char hexadecimal[100];
    int index = 0;

    while (decimal > 0) {
        int remainder = decimal % 16;
        if (remainder < 10)
            hexadecimal[index++] = remainder + '0';
        else
            hexadecimal[index++] = remainder - 10 + 'A';

        decimal /= 16;
    }

    printf("Hexadecimal equivalent: ");
    for (int i = index - 1; i >= 0; i--)
        printf("%c", hexadecimal[i]);
    printf("\n");
}

int main() {
    int decimal;
printf("Prajakta Pokhriyal \n");
    printf("Enter a decimal number: ");
    scanf("%d", &decimal);

    decimalToHexadecimal(decimal);

    return 0;
}
