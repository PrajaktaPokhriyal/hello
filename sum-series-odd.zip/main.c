#include <stdio.h>

int sumOddNumbers(int n) {
    if (n == 1)
        return 1;
    else
        return (2 * n - 1) + sumOddNumbers(n - 1);
}

int main() {
    int n;
    printf("Enter the value of n: ");
    scanf("%d", &n);

    int result = sumOddNumbers(n);
    printf("Sum of the series up to %d terms of odd numbers is: %d\n", n, result);

    return 0;
}
