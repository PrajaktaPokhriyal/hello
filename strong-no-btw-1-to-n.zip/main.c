#include <stdio.h>

int factorial(int num) {
    if (num == 0 || num == 1)
        return 1;
    else
        return num * factorial(num - 1);
}

int isStrong(int num) {
    int originalNum = num;
    int sum = 0;

    while (num != 0) {
        int digit = num % 10;
        sum += factorial(digit);
        num /= 10;
    }

    return (sum == originalNum);
}

void printStrongNumbers(int n) {
    printf("Strong numbers between 1 and %d are:\n", n);

    for (int i = 1; i <= n; i++) {
        if (isStrong(i))
            printf("%d ", i);
    }

    printf("\n");
}

int main() {
    int n;
printf("Prajakta Pokhriyal \n");
    printf("Enter a number: ");
    scanf("%d", &n);

    printStrongNumbers(n);

    return 0;
}
