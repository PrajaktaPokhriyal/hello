#include <stdio.h>

int sumOfEven(int n) {
    if (n == 2) {
        return 2;
    } else {
        return n + sumOfEven(n - 2);
    }
}

int main() {
    int n, sum;
    
    printf("Enter the value of n: ");
    scanf("%d", &n);
    
    if (n % 2 != 0) {
        printf("Please enter an even number.\n");
        return 1;
    }
    
    sum = sumOfEven(n);
    printf("Sum of even numbers from 2 to %d is %d.\n", n, sum);

    return 0;
}
