#include <stdio.h>
         #include <math.h>
float areaOfRightAngleTriangle(float base, float height) {
    	return 0.5 * base * height;
}
float areaOfIsoscelesTriangle(float base, float sides) {
    	float height = sqrt(sides * sides - (base * base) / 4);
    	return 0.5 * base * height;
}

float areaOfAnyTriangle(float side1, float side2, float side3) {
    	float s = (side1 + side2 + side3) / 2;
    	return sqrt(s * (s - side1) * (s - side2) * (s - side3));
}

int main() {
    	float base, height, sides[3];
    	int choice;

    	printf("Choose the type of triangle:\n");
    	printf("1. Right-Angled Triangle\n");
   	 printf("2. Isosceles Triangle\n");
    	printf("3. Any Triangle\n");
    	scanf("%d", &choice);

    	switch (choice) {
       	 case 1:
           printf("Enter the base length: ");
scanf("%f", &base);
            	printf("Enter the height: ");
            	scanf("%f", &height);
           printf("Area of the right-angled triangle is: %.2f\n", 
	areaOfRightAngleTriangle(base, height));
            	break;
       		case 2:
            	printf("Enter the base length: ");
           	 scanf("%f", &base);
           	 printf("Enter the length of equal sides: ");
            	scanf("%f", &sides[0]);
            	printf("Area of the isosceles triangle is: %.2f\n", 
		areaOfIsoscelesTriangle(base, sides[0]));
          	 break;
        		case 3:
           	 printf("Enter the lengths of the three sides: ");
            	scanf("%f %f %f", &sides[0], &sides[1], &sides[2]);
            	printf("Area of the triangle is: %.2f\n",
 areaOfAnyTriangle(sides[0], sides[1], sides[2]));
            	break;
        		default:
            	printf("Invalid choice\n");

}
return 0;
}
