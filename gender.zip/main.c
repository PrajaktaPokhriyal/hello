           #include <stdio.h>
           int main() {
    	 char gender;
printf("Enter a single character (M/F): ");
 	scanf("%c", &gender);
 if (gender == 'M' || gender == 'm') {
        	printf("Gender: Male\n");
    	} else if (gender == 'F' || gender == 'f') {
       	 printf("Gender: Female\n");
    	} else {
      printf("Invalid input. Please enter 'M' for Male or 'F' for Female.\n");
     	}
  	return 0;
}
