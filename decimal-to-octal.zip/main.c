#include <stdio.h>

void decimalToOctal(int decimal) {
    int octal[100];
    int i = 0;

    while (decimal > 0) {
        octal[i] = decimal % 8;
        decimal /= 8;
        i++;
    }

    printf("Octal equivalent: ");
    for (int j = i - 1; j >= 0; j--)
        printf("%d", octal[j]);
    printf("\n");
}

int main() {
    int decimal;
printf("Prajakta Pokhriyal \n");
    printf("Enter a decimal number: ");
    scanf("%d", &decimal);

    decimalToOctal(decimal);

    return 0;
}
