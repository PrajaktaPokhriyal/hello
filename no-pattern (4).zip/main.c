#include <stdio.h>

void printSquareNumberPattern(int n) {
    int i, j;

    for (i = 1; i <= n; i++) {
        for (j = 1; j <= n; j++) {
            if ((i + j) % 2 == 0)
                printf("1");
            else
                printf("0");
        }
        printf("\n");
    }
}

int main() {
    int n;
    printf("Prajakta Pokhriyal \n");
    printf("Enter the number of rows: ");
    scanf("%d", &n);
    printSquareNumberPattern(n);

    return 0;
}
