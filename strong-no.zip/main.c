#include <stdio.h>

int factorial(int num) {
    if (num == 0 || num == 1)
        return 1;
    else
        return num * factorial(num - 1);
}

int isStrong(int num) {
    int originalNum = num;
    int sum = 0;

    while (num != 0) {
        int digit = num % 10;
        sum += factorial(digit);
        num /= 10;
    }

    return (sum == originalNum);
}

int main() {
    int number;
printf("Prajakta Pokhriyal \n");
    printf("Enter a number: ");
    scanf("%d", &number);

    if (isStrong(number))
        printf("%d is a Strong number.\n", number);
    else
        printf("%d is not a Strong number.\n", number);

    return 0;
}
