    #include <string.h>
    int main() {
   char correctUsername[] = "Prajakta Pokhriyal";
   char correctPassword[] = "Prajakta";
   char username[20];
    char password[20];
    printf("Enter your password: ");
    scanf("%s", password);
   printf("Enter your username: ");
   scanf("%s", username);
    if (strcmp(username, correctUsername) == 0 && strcmp(password,       correctPassword) == 0) {
     printf("Login successful!\n");
    } else {
     

 printf("\nLogin failed. Please check your username and 
     password.\n");
     }
    return 0;
     }
