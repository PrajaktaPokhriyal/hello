
#include <stdio.h>
void printSquareNumberPattern(int n) {
    int i, j;

    for (i = 1; i <= n; i++) {
        for (j = 1; j <= n; j++) {
            if (i == n / 2 + 1 || j == n / 2 + 1)
                printf("0");
            else
                printf("1");
        }
        printf("\n");
    }
}

int main() {
    int n;
    printf("Prajakta Pokhriyal \n");
    printf("Enter the number of rows (odd): ");
    scanf("%d", &n);

    if (n % 2 != 0)
        printSquareNumberPattern(n);
    else
        printf("Please enter an odd number for the square pattern.\n");

    return 0;

}
