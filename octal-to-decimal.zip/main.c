#include <stdio.h>
#include <math.h>

int octalToDecimal(int octal) {
    int decimal = 0, i = 0;

    while (octal != 0) {
        int remainder = octal % 10;
        decimal += remainder * pow(8, i);
        ++i;
        octal /= 10;
    }

    return decimal;
}

int main() {
    int octal;

    printf("Enter an octal number: ");
    scanf("%o", &octal);

    int decimal = octalToDecimal(octal);

    printf("Decimal equivalent: %d\n", decimal);

    return 0;
}
