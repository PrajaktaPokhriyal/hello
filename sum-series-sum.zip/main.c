
#include <stdio.h>
int sumSeries(int n) {
    if (n == 0) {
        return 0;
    } else {
        return n + sumSeries(n - 1);
    }
}

int main() {
    int num, sum;

    printf("Enter a positive integer: ");
    scanf("%d", &num);

    if (num < 0) {
        printf("Please enter a positive integer.\n");
        return 1;
    }

    sum = sumSeries(num);

    printf("Sum of the series 1 + 2 + 3 + ... + %d = %d\n", num, sum);

    return 0;
}
