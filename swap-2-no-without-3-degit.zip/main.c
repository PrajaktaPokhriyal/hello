         	#include <stdio.h>
          int main() {
int a,b;
printf("Enter 1st number:");
scanf("%d",&a);
printf("Enter 2nd number:");
scanf("%d",&b);
a=a+b;
b=a-b;
a=a-b;
printf("int%d",a);
printf("int%d",b);
printf("%d",a);
printf("/n In a Swap Number are a=%d , b=%d",a,b);
return 0; 
}
