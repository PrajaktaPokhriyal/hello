#include <stdio.h>

int main() {
    int number, swapped_number, first_digit, last_digit, temp, power_of_10;
printf("Prajakta Pokhriyal \n");
    printf("Enter a number: ");
    scanf("%d", &number);

    // Extracting the last digit
    last_digit = number % 10;

    // Finding the number of digits
    temp = number;
    int digits_count = 0;
    while (temp != 0) {
        temp /= 10;
        digits_count++;
    }

    // Finding the first digit
    power_of_10 = 1;
    for (int i = 1; i < digits_count; i++) {
        power_of_10 *= 10;
    }
    first_digit = number / power_of_10;

    // Swapping the first and last digits
    swapped_number = last_digit * power_of_10;
    swapped_number += number % power_of_10;
    swapped_number -= last_digit;
    swapped_number += first_digit;

    printf("Number after swapping first and last digits: %d\n", swapped_number);

    return 0;
}

