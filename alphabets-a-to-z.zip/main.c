/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
char ch;
printf("Prajakta {Pokhriyal\n");
printf("Alphabets from a to z are :\n");
for(ch='a';ch<='z';ch++)
{
    printf("%c\n",ch);
}

    return 0;
}

