#include <stdio.h>

void printSquarePattern(int n) {
    int i, j;

    for (i = 1; i <= n; i++) {
        for (j = 1; j <= n; j++)
            printf("1");
        printf("\n");
    }
}

int main() {
    int n;
    printf("Prajakta Pokhriyal \n");
    printf("Enter the number of rows: ");
    scanf("%d", &n);
    printSquarePattern(n);

    return 0;
}

