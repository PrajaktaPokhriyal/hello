#include <stdio.h>
#include <stdbool.h>

bool isPrime(int num) {
    if (num <= 1)
        return false;

    for (int i = 2; i * i <= num; i++) {
        if (num % i == 0)
            return false;
    }

    return true;
}

void printPrimes(int n) {
    printf("Prime numbers between 1 and %d are:\n", n);

    for (int i = 2; i <= n; i++) {
        if (isPrime(i))
            printf("%d ", i);
    }
}

int main() {
    int n;
printf("Prajakta Pokhriyal \n");
    printf("Enter a number: ");
    scanf("%d", &n);

    printPrimes(n);

    return 0;
}
