#include <stdio.h>

void primeFactors(int num) {
    printf("Prime factors of %d are: ", num);

    for (int i = 2; i <= num; i++) {
        while (num % i == 0) {
            printf("%d ", i);
            num /= i;
        }
    }

    // If num is still greater than 1, it's a prime factor
    if (num > 1)
        printf("%d ", num);

    printf("\n");
}

int main() {
    int number;
printf("Prajakta Pokhriyal \n");
    printf("Enter a number: ");
    scanf("%d", &number);

    primeFactors(number);

    return 0;
}
