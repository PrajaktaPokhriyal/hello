#include <stdio.h>

void print_factors(int num) {
    
    printf("Factors of %d: ", num);

    for (int i = 1; i <= num; i++) {
        if (num % i == 0)
            printf("%d ", i);
    }

    printf("\n");
}

int main() {
    int num;
printf("Prajakta Pokhriyal \n");
    printf("Enter a number: ");
    scanf("%d", &num);

    if (num < 0) {
        printf("Please enter a non-negative number.\n");
        return 1;
    }

    print_factors(num);

    return 0;
}
