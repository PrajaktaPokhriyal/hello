#include <stdio.h>
#include <stdbool.h>

bool isPrime(int num) {
    if (num <= 1)
        return false;

    for (int i = 2; i * i <= num; i++) {
        if (num % i == 0)
            return false;
    }

    return true;
}

int sumPrimes(int n) {
    int sum = 0;

    for (int i = 2; i <= n; i++) {
        if (isPrime(i))
            sum += i;
    }

    return sum;
}

int main() {
    int n;
printf("Prajakta Pokhriyal \n");
    printf("Enter a number: ");
    scanf("%d", &n);

    int primeSum = sumPrimes(n);

    printf("Sum of prime numbers between 1 and %d is: %d", n, primeSum);

    return 0;
}
