#include <stdio.h>

int main() {
    printf("Prajakta Pokhriyal \n");
    printf("ASCII Characters and their Values:\n");
    for (int i = 0; i <= 127; ++i) {
        printf("ASCII value %d: %c\n", i, (char)i);
    }
    return 0;
}
