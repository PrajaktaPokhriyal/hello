    #include <stdio.h>
    int main() {
    int num1 = 10;
    int num2 = 5;
    printf("Original value of num1: %d\n", num1);
    num1 = ++num1; 
    printf("Updated value of num1: %d\n", num1);
    printf("Original value of num2: %d\n", num2);
    num2 = --num2;
    printf("Updated value of num2: %d\n", num2);
   return 0;
  }
