#include <stdio.h>
int main() {
int a,b,l;
printf("Enter the length of the rectangle:");
scanf("%d",&l);
printf("Enter the breadth of the rectangle:");
scanf("%d",&b);
a = l*b;
printf("/n The area of the rectangle is : %d",a);
 	return 0;
}
