
#include <stdio.h>
int main() {
       	float length, width, height;
   	 float area, volume;
    	printf("Enter the length of the cuboid: ");
    	scanf("%f", &length);
   	 printf("Enter the width of the cuboid: ");
    	scanf("%f", &width);
  	 printf("Enter the height of the cuboid: ");
    	scanf("%f", &height );
    	area = 2 * (length * width + width * height + height * length);
   	 volume = length * width * height;
    	printf("The surface area of the cuboid is: %.2f square units\n", area);
    	printf("The volume of the cuboid is: %.2f cubic units\n", volume);
   	 return 0;
}
