
#include <stdio.h>

int main()
{
 int i;
 printf("Prajakta Pokhriyal\n");
 printf("Enter a number :\n");
 for(i=1;i<=100;i++)
 {
     if (i%2!=0){
         printf("%d\n",i);

     }}

    return 0;
}


