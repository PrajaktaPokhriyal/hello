#include <stdio.h>

int isPerfect(int num) {
    int sum = 0;

    for (int i = 1; i < num; i++) {
        if (num % i == 0)
            sum += i;
    }

    return (sum == num);
}

void printPerfectNumbers(int n) {
    printf("Perfect numbers between 1 and %d are:\n", n);

    for (int i = 1; i <= n; i++) {
        if (isPerfect(i))
            printf("%d ", i);
    }

    printf("\n");
}

int main() {
    int n;
printf("Prajakta Pokhriyal \n");
    printf("Enter a number: ");
    scanf("%d", &n);

    printPerfectNumbers(n);

    return 0;
}
