/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main() {
    float costPrice, sellingPrice, profitOrLoss;

    // Input the cost price and selling price
    printf("Enter the cost price: ");
    scanf("%f", &costPrice);
    printf("Enter the selling price: ");
    scanf("%f", &sellingPrice);

    // Calculate profit or loss
    profitOrLoss = sellingPrice - costPrice;

    if (profitOrLoss > 0) {
        printf("Profit: $%.2f\n", profitOrLoss);
    } else if (profitOrLoss < 0) {
        printf("Loss: $%.2f\n", -profitOrLoss);
    } else {
        printf("No profit, no loss.\n");
    }

    return 0;
}

