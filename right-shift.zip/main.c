      #include <stdio.h>
      int main() {
      int num, shift;
      printf("Prajakta Pokhriyal ");
      printf("\nEnter a positive number: ");
      scanf("%u", &num);
      if (num <= 0) {
      printf("Please enter a positive number.\n");
      return 1; 
      }
     printf("Enter the number of bits to right shift: ");
     scanf("%u", &shift);
     int result = num >> shift;
     printf("Result of right shift: %u\n", result);
     return 0; }
