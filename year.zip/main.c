/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h> 

int main()

{
 int days, years, weeks;
 days = 1329;
 // Converts days to years, weeks and days

 years = days/365; 

 weeks = (days % 365)/7;
 days = days- ((years*365) + (weeks*7));
 printf("Years: %d\n", years);
 printf("Weeks: %d\n", weeks);
 printf("Days: %d \n", days);
 return 0;
}