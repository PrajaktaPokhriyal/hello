#include <stdio.h>

void printHollowInvertedPyramid(int rows) {
    int i, j;

    for (i = 1; i <= rows; i++) {
        for (j = 1; j < i; j++)
            printf(" ");
        for (j = 1; j <= 2 * (rows - i) + 1; j++) {
            if (j == 1 || j == 2 * (rows - i) + 1 || i == rows)
                printf("*");
            else
                printf(" ");
        }
        printf("\n");
    }
}

int main() {
    int rows;
printf("Prajakta Pokhriyal\n");
    printf("Enter the number of rows: ");
    scanf("%d", &rows);

    printHollowInvertedPyramid(rows);

    return 0;
}
