#include <stdio.h>

int main() {
    int number, originalNumber, product = 1, digit;
printf("Prajakta Pokhriyal \n");
    printf("Enter an integer: ");
    scanf("%d", &number);

    originalNumber = number;

    // Calculate product of digits
    while (number != 0) {
        digit = number % 10;
        product *= digit;
        number /= 10;
    }

    printf("Product of digits of %d = %d\n", originalNumber, product);

    return 0;
}
